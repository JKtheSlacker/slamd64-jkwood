# Use framebuffer by default if no xorg.conf is found:
if [ ! -r etc/X11/xorg.conf -a -r etc/X11/xorg.conf-vesa ]; then
  cp -a etc/X11/xorg.conf-vesa etc/X11/xorg.conf
fi
( cd usr/lib/X11 ; rm -rf fonts )
( cd usr/lib/X11 ; ln -sf ../../share/fonts fonts )
( cd usr/bin ; rm -rf X11 )
( cd usr/bin ; ln -sf . X11 )
( cd usr ; rm -rf X11 )
( cd usr ; ln -sf lib X11 )
