( cd bin ; rm -rf mt )
( cd bin ; ln -sf  mt-st mt )
( cd usr/man/man1 ; rm -rf mt.1.gz )
( cd usr/man/man1 ; ln -sf mt-st.1.gz mt.1.gz )
