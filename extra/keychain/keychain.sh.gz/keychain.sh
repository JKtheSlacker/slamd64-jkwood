#!/bin/sh
keychain --agents ssh,gpg -q

host=${HOSTNAME:-`uname -n`}

[[ -f $HOME/.keychain/$host-sh ]] && \
 source $HOME/.keychain/$host-sh
[[ -f $HOME/.keychain/$host-sh-gpg ]] && \
 source  $HOME/.keychain/$host-sh-gpg
