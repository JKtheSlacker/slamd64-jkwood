#!/bin/sh
# If there's no mozilla here, then take over:
if [ ! -r usr/bin/mozilla ]; then
  ( cd usr/bin ; ln -sf seamonkey mozilla )
fi
# Add pkgconfig links which might be needed to compile some things:
( cd usr/lib64/pkgconfig
  if [ ! -r mozilla-gtkmozembed.pc -a -r seamonkey-gtkmozembed.pc ]; then
    ln -sf seamonkey-gtkmozembed.pc mozilla-gtkmozembed.pc
  fi
  if [ ! -r mozilla-js.pc -a -r seamonkey-js.pc ]; then
    ln -sf seamonkey-js.pc mozilla-js.pc
  fi
  if [ ! -r mozilla-nspr.pc -a -r seamonkey-nspr.pc ]; then
    ln -sf seamonkey-nspr.pc mozilla-nspr.pc
  fi
  if [ ! -r mozilla-nss.pc -a -r seamonkey-nss.pc ]; then
    ln -sf seamonkey-nss.pc mozilla-nss.pc
  fi
  if [ ! -r mozilla-plugin.pc -a -r seamonkey-plugin.pc ]; then
    ln -sf seamonkey-plugin.pc mozilla-plugin.pc
  fi
  if [ ! -r mozilla-xpcom.pc -a -r seamonkey-xpcom.pc ]; then
    ln -sf seamonkey-xpcom.pc mozilla-xpcom.pc
  fi
)
