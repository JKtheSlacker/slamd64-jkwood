# Since the use of icon caching is optional, and has to be kept in sync
# somehow (like a "registry" through a cron job, or whatever, I tend to
# think the user should be the one to choose if they really want to set
# this up or not:
 
# I give up.  ;-)  Better to use it than not, at least it seems for now.
# Using an absolute path (/usr/bin/gtk-update-icon-cache) will make
# this script function only on a running system.  Otherwise an end-of-
# install script will take care of this job.

for icondir in usr/share/icons/hicolor usr/share/icons ; do
  if [ -d $icondir ]; then
    if [ -x /usr/bin/gtk-update-icon-cache ]; then
      chroot . /usr/bin/gtk-update-icon-cache -f -t $icondir 1> /dev/null 2> /dev/null
    fi
  fi
done
