( cd usr/lib64 ; rm -rf libjpeg.so.62 )
( cd usr/lib64 ; ln -sf libjpeg.so.62.0.0 libjpeg.so.62 )
( cd usr/lib64 ; rm -rf libjpeg.so )
( cd usr/lib64 ; ln -sf libjpeg.so.62 libjpeg.so )
