if [ ! -L usr/share/pkgconfig ]; then
  mkdir -p usr/lib/pkgconfig
  mv usr/share/pkgconfig/* usr/lib/pkgconfig 2> /dev/null
  rmdir usr/share/pkgconfig
  ( cd usr/share ; ln -sf ../lib/pkgconfig . )
fi
